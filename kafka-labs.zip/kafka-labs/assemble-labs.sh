#!/bin/bash


$ES_HOME/utils/labs/labs-assembler.sh  lab-assembly.txt  $@

