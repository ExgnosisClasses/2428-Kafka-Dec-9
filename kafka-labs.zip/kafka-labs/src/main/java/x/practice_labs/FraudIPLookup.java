package x.practice_labs;

public interface FraudIPLookup {
	
	public boolean isFraudIP (String ipAddress);

}
