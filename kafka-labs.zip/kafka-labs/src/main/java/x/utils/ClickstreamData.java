package x.utils;

public class ClickstreamData {
  public long timestamp;
  public String domain;
  public int cost;
  public String user;
  public String campaign;
  public String ip;
  public String action;

}
